mapJep <-
function (sp, confidence = 'high', map = T, getPoly = F) 
{
	options(stringsAsFactors=FALSE)

    require(rgdal)
    data(esu_shp)
    data(pts)
    data(ca)
    names(pts) <- c("esu", "id", "type")
    pts$id <- gsub("_$", "", pts$id)
    pts$id <- gsub("_", " ", pts$id)
    pts2 = pts
    if (confidence == "high") 
        pts2 = pts2[pts2$id == sp & pts2$type == "Present", ]
    if (confidence == "medium") 
        pts2 = pts2[pts2$id == sp & pts2$type != "Possible", ]
    if (confidence == "low") 
        pts2 = pts2[pts2$id == sp, ]
    col_index = data.frame(esu_shp@data$ESUKEY, rep(NA, 228))
    names(col_index) = c("esu", "col")
    col_index$col = as.character(col_index$col)
    pts_temp = pts2[pts2$id == sp, ]
    col_index$col <- NA
    col_index$col[col_index$esu %in% pts_temp[, 1]] = "black"

	if(map == TRUE)
		{
			 plot(ca)
			 plot(esu_shp, col = col_index$col, lwd = 0.001, border = "black", 
				  asp = 1, add = T)
			 if (nrow(pts2[pts2$id == sp, ]) == 0) {
				  mtext("not found", 1)
			 }
			 else {
				  mtext(sp, 1)
			 }
		}
		
    if(getPoly == TRUE)
    	{
    		poly <- esu_shp[esu_shp@data$ESUKEY %in% pts_temp[, 1], ]
			row.names(poly@data)
			
			return(poly)
			
		}	
}