getConsortium <-
function(sp, getInfra = T)
{	
	options(stringsAsFactors=FALSE)

	base <- "http://herbaria4.herb.berkeley.edu/cgi-bin/get_coords_for_name.pl?taxon="

	res = 1

	sp <- gsub(' ', '+', sp)

	for(i in 1:length(sp))
	{
		if(getInfra == F){

			url <- paste(base, sp[i], '&infras=0', sep = '')
			temp <- readLines(url, warn = F)

				if(sapply(strsplit(temp, ","), length) == 1){
					next
					print(paste(gsub('[+]', ' ', sp[i]), 'not found', sep = ' '))

						} else {
							temp <- gsub('\t', ',', temp)
							temp <- unlist(strsplit(temp, ','))
							temp <- t(matrix(temp, nrow = 4))

							temp2 <- data.frame(sp = temp[ , 1], 
										accession = temp[, 2], 
										lat = as.numeric(temp[, 3]), 
										lon = as.numeric(temp[, 4])
										)
										
							print(paste(gsub('[+]', ' ', sp[i]), 'found, downloaded', nrow(temp2), 'records', sep = ' '))
						}
					
		} else {
			url <- paste(base, sp[i], '&infras=1', sep = '')
			temp <- readLines(url, warn = F)

				if(sapply(strsplit(temp, ","), length) == 1){
					print(paste(gsub('[+]', ' ', sp[i]), 'not found', sep = ' '))
					next
					} else {

						temp <- gsub('\t', ',', temp)
						temp <- gsub('<br><hr><br>', '', temp)
						temp <- unlist(strsplit(temp, ','))
						temp <- t(matrix(temp, nrow = 4))
						temp2 <- data.frame(sp = temp[ , 1], 
									accession = temp[, 2], 
									lat = as.numeric(temp[, 3]), 
									lon = as.numeric(temp[, 4])
									)

						print(paste(gsub('[+]', ' ', sp[i]), 'found, downloaded', nrow(temp2), 'records', sep = ' '))

						}
			}

		if(length(res) == 1)
			{
				res <- temp2
				}
			else{
				res <- rbind(res, temp2)
			}
			
		rm(list = c('temp', 'temp2'))

	}
		if(length(res) == 1){
			print('no records found, nothing to return')
			} else {
				res[,1] <- gsub('[+]', ' ', res[,1])
				return(res)	
				}
}