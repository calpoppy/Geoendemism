getJep <-
function (sp, fields = "all") 
{
    data(tjm2_annotated)

	options(stringsAsFactors=FALSE)
	
	# decapitalize familys
		tjm2_annotated$family = paste(substr(tjm2_annotated$family, 1,1), tolower(substring(tjm2_annotated$family, 2)),sep="")

	# add var or subsp as necessary
		temp = tjm2_annotated[match(sp, tjm2_annotated[, 1]), 1]
		not_matched_sp = sp[is.na(temp)]
		
		for(i in 1:length(not_matched_sp))
			{
				# try adding var.
					temp_id =  paste(unlist(lapply(strsplit(not_matched_sp[i], " ", fixed = T), '[', 1)), unlist(lapply(strsplit(not_matched_sp[i], " ", fixed = T), '[', 2)), 'var.', unlist(lapply(strsplit(not_matched_sp[i], " ", fixed = T), '[', 2)))
					if(!is.na(match(temp_id, tjm2_annotated[,1]))) not_matched_sp[i] = temp_id
					
				# try adding subsp.
					temp_id =  paste(unlist(lapply(strsplit(not_matched_sp[i], " ", fixed = T), '[', 1)), unlist(lapply(strsplit(not_matched_sp[i], " ", fixed = T), '[', 2)), 'subsp.', unlist(lapply(strsplit(not_matched_sp[i], " ", fixed = T), '[', 2)))
					if(!is.na(match(temp_id, tjm2_annotated[,1]))) not_matched_sp[i] = temp_id
			}

		sp2 = sp
		sp2[is.na(temp)] = not_matched_sp


	# return data (all or a subset specified by 'fields')
		 if (fields[1] != "all") {
			  res = tjm2_annotated[match(sp2, tjm2_annotated[, 1]), fields]
			  #res = res[, -1]
			  res = data.frame(your_sp = sp, matched_sp = sp2,  res, stringsAsFactors = F)
				res[is.na(res[,3]), 'matched_sp'] = "not found"

				names(res)[3:(2 + length(fields))] = fields

			  if(length(res[res$matched_sp == 'not found', 'your_sp']) > 0)
					{
					print('Warning: The following were not found:')
				  print(res[res$matched_sp == 'not found', 'your_sp'])
				  print('Check spelling. Also, check taxonomy notes here: http://ucjeps.berkeley.edu/interchange/')
				  }
			  return(res)

		 }
		 else {
			  res = tjm2_annotated[match(sp2, tjm2_annotated[, 1]), ]
			  res = data.frame(your_sp = sp, matched_sp = res[, 1],  res, stringsAsFactors = F)
			  res = res[, -3]
				res[is.na(res$matched_sp), 'matched_sp'] = "not found"
					  if(length(res[res$matched_sp == 'not found', 'your_sp']) > 0)
							{
						print('Warning: The following were not found:')
						  print(res[res$matched_sp == 'not found', 'your_sp'])
						  print('Check spelling. Also, check taxonomy notes here: http://ucjeps.berkeley.edu/interchange/')
						  }	
			  return(res)
		 }
}
