xwalk <-

function (sp = species_list) 
{

	options(stringsAsFactors=FALSE)

   data(tjm1tjm2)
	data(tjm2_annotated)
	new = tjm1tjm2[match(sp, tjm1tjm2[, 1]), 2]

	# for taxa not in xwalk, add var or subsp and try matching again
		findme = sp[is.na(new)]

		if(length(findme) > 0)
		{

			# first, strip any existing var. or subsp.
				findme2 = findme
				for(i in 1:length(findme)) findme2[i] = paste(unlist(strsplit(findme[i], " ", fixed = T))[1], unlist(strsplit(findme[i], " ", fixed = T))[2])

			add_var = vector()
	
			for(i in 1:length(findme2)) add_var[i] = paste(findme2[i], 'var.', strsplit(findme2[i], ' ')[[1]][2])
				new[match(findme[add_var %in% tjm1tjm2$tjm1], sp)] = tjm1tjm2$tjm2[match(add_var[add_var %in% tjm1tjm2$tjm1], tjm1tjm2$tjm1)]
	
			add_subsp = vector()
			for(i in 1:length(findme2)) add_subsp[i] = paste(findme2[i], 'subsp.', strsplit(findme2[i], ' ')[[1]][2])
				new[match(findme[add_subsp %in% tjm1tjm2$tjm1], sp)] = tjm1tjm2$tjm2[match(add_subsp[add_subsp %in% tjm1tjm2$tjm1], tjm1tjm2$tjm1)]
	
			rm(findme)
			rm(add_var)
			rm(add_subsp)
		}
		
	   index = is.na(new)
		new[index]= sp[index]

		translated = vector(length = length(sp))
		translated[index] = 'no'
		translated[!index] = 'yes'
		
		in_TJM2 = vector(length = length(sp))
		
		in_TJM2[new %in% tjm2_annotated$name] = 'yes'
		in_TJM2[!new %in% tjm2_annotated$name] = 'no'


		# for taxa not in TJM2, add var or subsp and try matching again
			findme = new[in_TJM2 == 'no']

		if(length(findme) > 0)
		{			

				add_var = vector()
				for(i in 1:length(findme)) add_var[i] = paste(findme[i], 'var.', strsplit(findme[i], ' ')[[1]][2])
				new[match(findme[add_var %in% tjm2_annotated$name], new)] = add_var[add_var %in% tjm2_annotated$name]
				
				add_subsp = vector()
				for(i in 1:length(findme)) add_subsp[i] = paste(findme[i], 'subsp.', strsplit(findme[i], ' ')[[1]][2])
				new[match(findme[add_subsp %in% tjm2_annotated$name], new)] = add_subsp[add_subsp %in% tjm2_annotated$name]
		}
		
		in_TJM2[new %in% tjm2_annotated$name] = 'yes'
		in_TJM2[!new %in% tjm2_annotated$name] = 'no'

    return(
    data.frame(sp, new, translated, in_TJM2)
    )
    
}
